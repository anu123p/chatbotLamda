'use strict';
const axios = require("axios");

module.exports.getInfo = async (event) => {
  // return {
  //   statusCode: 200,
  //   body: JSON.stringify(
  //     {
  //       message: 'Go Serverless v1.0! Your function executed successfully!',
  //       input: event,
  //     },
  //     null,
  //     2
  //   ),
  // };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };


    //const city = event.currentIntent.slots["city"];
    const url = "https://api.covid19api.com/summary";

    try {
        const response = await axios.get(url);
        const data = response.data;
        console.log(data);

        const answer = "Total New Confirmed cases are  " + data.Global.NewConfirmed +
                        " Total Confirmed cases are " + data.Global.TotalConfirmed +
                        " New Deaths are  " + data.Global.NewDeaths +
                        " Total Deaths are " + data.Global.TotalDeaths +
                        " New Recovered Cases are " + data.Global.NewRecovered +
                        "Total Recovered cases are " + data.Global.TotalRecovered ;

        return {
            "sessionAttributes": {},
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Fulfilled",
                "message": {
                    "contentType": "PlainText",
                    "content": answer
                }
            }
        }
    } catch (error) {
        console.log(error);
    }
};
